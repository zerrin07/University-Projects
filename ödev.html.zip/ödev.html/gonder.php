<meta http-equiv="refresh" content="2;URL= iletişim.html">
<?
require("class.phpmailler.php");

$mail = new PHPNailer();
$mail->IsSMTP();
$mail->Host    = "mail.zerrinbhmnyr.com";
$mail->SMTPAuth  = true; 
$mail->Username = "zerrinbhmnyr7@gmail.com";
$mail->Password = "123456";
$mail->CharSet = "UTF-8";
$mail->Port = "587";
$mail->From = "zerrinbhmnyr7@gmail.com";
$mail->Fromname = "giden ismi";
$mail->AddAddress = ("zerrinbhmnyr7@gmail.com",websitenizden gelen ileti.");
$mail->Subject = $_POST['isim'];
$mail->Body = implode("  ",$_POST);
if(!$mail->Send())
{
    echo "Mesaj Gönderilemedi <p>";
    echo "Mailer Error:" , $mail->ErrorInfo;
    exit;
}
echo '<script type="text/javascript">alert("E-postanız Başarı ile Gönderilmiştir.");</script>


?>

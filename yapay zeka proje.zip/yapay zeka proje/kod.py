import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from keras.models import Sequential
from keras.layers import Dense

dataset = pd.read_csv('diabetes.csv')
dataset.head()

dataset.isna().sum() 
dataframeInNumpy = dataset.values #take the datarame to a numpy typed nd-array
inputVariables = dataframeInNumpy[:,:8]
outputVariables = dataframeInNumpy[:,8:]

model = Sequential()
model.add(Dense(15, input_dim=8, kernel_initializer='random_uniform', activation='relu'))
model.add(Dense(7, input_dim=8, kernel_initializer='random_uniform', activation='relu'))
model.add(Dense(1, input_dim=8, kernel_initializer='random_uniform', activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
model.fit(inputVariables,outputVariables,epochs=150,batch_size=10)

scores = model.evaluate(inputVariables,outputVariables)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
print("the new predection is:", model.predict(np.array([[6,142,72,45,0,38.6,0.627,50]])))
print("the new predection is:", model.predict(np.array([[1,109,30,38,83,53.3,0.193,33]])))
# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

